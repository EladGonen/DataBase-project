-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `job_id` int NOT NULL AUTO_INCREMENT,
  `job_title` varchar(256) DEFAULT NULL,
  `date_ordered` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `customer_id` int DEFAULT NULL,
  `notes` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`job_id`),
  KEY `j_customer_id_idx` (`customer_id`),
  CONSTRAINT `j_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (100,'google company','2015-05-01 00:00:00','2015-09-01 00:00:00',4,NULL),(101,'Dan\'s house- electrical work','2016-04-01 00:00:00','2016-04-02 00:00:00',5,NULL),(102,'Lior\'s house - paint & electrical','2020-01-01 00:00:00','2020-01-01 14:00:00',1,NULL),(103,'Burger King company - store renovation','2018-01-01 00:00:00','2018-05-20 00:00:00',6,NULL),(104,'Yanir\'s garden house','2019-04-05 00:00:00','2019-04-06 00:00:00',2,NULL),(105,'facebook company','2017-03-01 00:00:00','2018-04-01 00:00:00',7,NULL),(106,'Yossi\'s house','2015-02-20 00:00:00','2015-02-25 00:00:00',8,NULL),(107,'Alon\'s house','2016-08-24 00:00:00','2016-08-30 00:00:00',9,NULL),(108,'Elad\'s house','2014-04-01 13:00:00','2014-04-01 18:00:00',3,NULL),(109,'Roz\'s house','2022-01-01 00:00:00','2022-08-15 00:00:00',10,NULL),(110,'Nissim\'s house','2021-01-01 14:00:00','2021-01-01 15:30:00',12,NULL),(111,'Shira\'s house','2005-06-06 00:00:00','2005-06-09 00:00:00',11,NULL),(112,'Harel company','2001-08-01 00:00:00','2001-12-24 00:00:00',13,NULL),(113,'Microsoft company','2007-01-01 00:00:00','2008-01-01 00:00:00',14,NULL),(114,'Keshet company','2012-05-05 00:00:00','2012-09-09 00:00:00',15,NULL),(115,'Haifa Municipality','2020-02-01 00:00:00','2020-03-04 00:00:00',16,NULL),(116,'Ber-Sheva Municipality','2014-10-10 00:00:00','2014-11-01 00:00:00',17,NULL),(117,'Netanya Municipality','2013-09-01 00:00:00','2013-09-30 00:00:00',18,NULL),(118,'Tveria Municipality','2016-04-02 00:00:00','2016-05-10 00:00:00',17,NULL),(119,'Hila\'s house','2005-07-07 10:00:00','2005-07-07 12:00:00',20,NULL),(120,'Din\'s house','2017-08-01 00:00:00','2017-08-05 00:00:00',21,NULL);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-31 20:26:44
