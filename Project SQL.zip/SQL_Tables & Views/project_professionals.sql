-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `professionals`
--

DROP TABLE IF EXISTS `professionals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `professionals` (
  `Professional_id` int NOT NULL,
  `P_firstname` varchar(20) DEFAULT NULL,
  `P_lastname` varchar(20) DEFAULT NULL,
  `Birthdate` datetime DEFAULT NULL,
  `start_work_date` datetime DEFAULT NULL,
  PRIMARY KEY (`Professional_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professionals`
--

LOCK TABLES `professionals` WRITE;
/*!40000 ALTER TABLE `professionals` DISABLE KEYS */;
INSERT INTO `professionals` VALUES (208931045,'yan','ban','1998-05-01 00:00:00','2017-02-08 00:00:00'),(262432676,'Miguel','Tata','1995-12-25 00:00:00','2019-01-31 00:00:00'),(275692558,'Ruhama','Levi','1960-08-09 00:00:00','1990-03-23 00:00:00'),(287565729,'Yulia','Turk','2000-11-04 00:00:00','2001-01-02 00:00:00'),(295739945,'Greg','Odom','1984-07-14 00:00:00','2005-09-30 00:00:00'),(353634568,'Moa','Meir','2000-04-29 00:00:00','2020-03-01 00:00:00'),(381676365,'Mark','Kapolsky','1975-02-09 00:00:00','1998-05-08 00:00:00'),(524656322,'Nehoray','Bismark','1997-03-19 00:00:00','2021-06-12 00:00:00'),(563572118,'Mishel','Cohen','1991-04-13 00:00:00','2015-04-22 00:00:00'),(564972541,'Yair','Mena','1980-01-01 00:00:00','2000-11-23 00:00:00');
/*!40000 ALTER TABLE `professionals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-31 20:26:44
