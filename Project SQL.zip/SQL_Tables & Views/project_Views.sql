-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `tasks_in_jobs`
--

DROP TABLE IF EXISTS `tasks_in_jobs`;
/*!50001 DROP VIEW IF EXISTS `tasks_in_jobs`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `tasks_in_jobs` AS SELECT 
 1 AS `job_id`,
 1 AS `task_id`,
 1 AS `task_price`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `workers_per_task`
--

DROP TABLE IF EXISTS `workers_per_task`;
/*!50001 DROP VIEW IF EXISTS `workers_per_task`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `workers_per_task` AS SELECT 
 1 AS `task_id`,
 1 AS `workers`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `prices_of_jobs`
--

DROP TABLE IF EXISTS `prices_of_jobs`;
/*!50001 DROP VIEW IF EXISTS `prices_of_jobs`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `prices_of_jobs` AS SELECT 
 1 AS `job_id`,
 1 AS `job_title`,
 1 AS `job_price`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `tasks_per_job`
--

DROP TABLE IF EXISTS `tasks_per_job`;
/*!50001 DROP VIEW IF EXISTS `tasks_per_job`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `tasks_per_job` AS SELECT 
 1 AS `job_id`,
 1 AS `amount_of_tasks`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `tasks_in_jobs`
--

/*!50001 DROP VIEW IF EXISTS `tasks_in_jobs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `tasks_in_jobs` (`job_id`,`task_id`,`task_price`) AS select `jobs`.`job_id` AS `job_id`,`tasks`.`task_id` AS `task_id`,`tasks`.`task_price` AS `task_price` from (`jobs` join `tasks` on((`jobs`.`job_id` = `tasks`.`job_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `workers_per_task`
--

/*!50001 DROP VIEW IF EXISTS `workers_per_task`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `workers_per_task` (`task_id`,`workers`) AS select `tasks_professional`.`task_id` AS `task_id`,count(0) AS `count(*)` from `tasks_professional` group by `tasks_professional`.`task_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `prices_of_jobs`
--

/*!50001 DROP VIEW IF EXISTS `prices_of_jobs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `prices_of_jobs` (`job_id`,`job_title`,`job_price`) AS select `jobs`.`job_id` AS `job_id`,`jobs`.`job_title` AS `job_title`,sum(`tasks`.`task_price`) AS `job price` from (`jobs` join `tasks` on((`jobs`.`job_id` = `tasks`.`job_id`))) group by `jobs`.`job_title` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tasks_per_job`
--

/*!50001 DROP VIEW IF EXISTS `tasks_per_job`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `tasks_per_job` (`job_id`,`amount_of_tasks`) AS select `tasks`.`job_id` AS `job_id`,count(0) AS `count(*)` from `tasks` group by `tasks`.`job_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-31 20:26:45
