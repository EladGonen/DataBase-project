#view
#create or replace view prices_of_jobs(job_id,job_title,job_price) as
#select jobs.job_id ,jobs.job_title, sum(tasks.task_price) as "job price"
#from jobs join tasks
#on jobs.job_id = tasks.job_id 
#group by jobs.job_title;

#view
#create or replace view tasks_in_jobs(job_id,task_id,task_price) as
#select jobs.job_id, tasks.task_id, tasks.task_price
#from jobs join tasks
#on jobs.job_id = tasks.job_id;

#view
#create or replace view tasks_per_job(job_id, amount_of_tasks) as
#select job_id, count(*)
#from tasks
#group by job_id;

#view
#create or replace view workers_per_task(task_id, workers) as
#select task_id, count(*)
#from tasks_professional
#group by task_id


#  שאילתא המציגה את העבודה והמשימה הכי יקרה בה 
select *
from tasks_in_jobs tij
where task_price in
(select max(task_price)
from tasks_in_jobs 
where job_id = tij.job_id);

#שאילתה המציגה את מסר ההזמנות מאז ומעולם שביצע כל לקוח
select customer_id, count(*) as "number of order jobs"
from jobs
group by customer_id;

#מספר העובדים בכל משימה
select jobs.job_id, count(distinct tasks_professional.professional_id) as "number of workers"
from jobs join tasks
on jobs.job_id = tasks.job_id join tasks_professional
on tasks.task_id = tasks_professional.task_id
group by jobs.job_id;

#הצגת שם העבודה ומחירה
select jobs.job_title, sum(tasks.task_price) as "job price"
from jobs join tasks
on jobs.job_id = tasks.job_id 
group by jobs.job_title;

#man of the month
select p.professional_id, p.P_firstname, p.P_lastname , count(*) 
from tasks_professional tp join professionals p
on tp.Professional_id = p.Professional_id
where month(time_complete) = month(now()) and year(time_complete) = year(now())
group by professional_id
order by count(*) desc
limit 1;

#seniority rank
select Professional_id, P_firstname, P_lastname, round((datediff(now(), start_work_date) / 365),0) as "seniority"
from professionals
order by round((datediff(now(), start_work_date) / 365),0) desc;

#the biggest spender customer
select j.customer_id, sum(poj.job_price) as "total pay"
from jobs j join prices_of_jobs poj
on j.job_id = poj.job_id
group by j.customer_id
order by sum(poj.job_price) desc
limit 1;

#מציאת עובדים שנגמרו להם התוקף להכשרות
select pl.professional_id, pl.P_firstname,pl.P_lastname, ps.professions_id, ps.title, adddate(wwp.quailify_date, (30 * ps.months_of_validity_time)) as "expiry date" 
from professionals pl join workers_with_professions wwp
on pl.Professional_id = wwp.professional_id join professions ps
on wwp.profession_id = ps.professions_id
where adddate(wwp.quailify_date, (30 * ps.months_of_validity_time)) < now();

#סיווג כל עבודה האם היא ארוכה או לא
select job_id, job_title, 
case when (datediff(date_completed, date_ordered) / 365) > 1 then "long job"
else "short job" end as "job length"
from jobs;

select customer_id, phone_number,
case when substr(phone_number, 1,2) = "05" then "cellphone"
else "land line" end as "type number"
from customers_phone;

#salary per worker per task
select t.task_id, t.task_title, t.task_price, t.task_price*0.1 as "management_fee", truncate((t.task_price*0.9)/wpt.workers, 2) as "salary per worker"
from tasks t join workers_per_task wpt
on t.task_id = wpt.task_id;

#מספר לקוחות לפי ערים
select city,count(*) as "number of customers"
from customers
group by city

#DDL
#יצירת טבלת JOBS
create table jobs
(job_id int(4) primary key auto_increment,
job_title varchar(256),
date_ordered datetime,
date_completed datetime) auto_increment=100;


#שאר השאילתות מצורפות במצגת




